package srp;

public class SalaryCalculator {
	 public double calculateSalary(Employee employee) {
	        double baseSalary = 3000; // base salary for all employees

	        switch (employee.getRole()) {
	            case "Manager":
	                return baseSalary * 1.5;
	            case "Developer":
	                return baseSalary * 1.2;
	            case "Intern":
	                return baseSalary * 0.8;
	            default:
	                return baseSalary;
	        }
	    }
}
