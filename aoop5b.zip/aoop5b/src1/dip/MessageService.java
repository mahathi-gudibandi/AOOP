package dip;

public interface MessageService {
	void sendMessage(String message);
}
