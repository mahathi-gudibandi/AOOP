package isp;

public interface Worker {
	void work();
}
