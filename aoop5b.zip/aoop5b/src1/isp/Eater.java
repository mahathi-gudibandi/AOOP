package isp;

public interface Eater {
	void eat();
}
