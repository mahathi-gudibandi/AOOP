package com.example.musicstreaming;

public class EqualizerDecorator implements MusicPlayer {
	private MusicPlayer decoratedMusicPlayer;
    private String equalizerSetting;

    public EqualizerDecorator(MusicPlayer decoratedMusicPlayer, String equalizerSetting) {
        this.decoratedMusicPlayer = decoratedMusicPlayer;
        this.equalizerSetting = equalizerSetting;
    }

    @Override
    public void playMusic() {
        decoratedMusicPlayer.playMusic();
        System.out.println("Equalizer setting applied: " + equalizerSetting);
    }
}
