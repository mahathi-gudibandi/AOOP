package com.example.musicstreaming;

public class Main {
	 public static void main(String[] args) {
	       
	        MusicSource localFileMusic = new LocalFileMusic("song.mp3");
	        MusicPlayer player = new AdvancedMusicPlayer(localFileMusic);
	        player = new VolumeControlDecorator(player, 75);
	        player = new EqualizerDecorator(player, "Bass Boost");
	        player.playMusic();

	       
	        MusicSource onlineMusic = new OnlineStreamingMusic("");
	        player = new AdvancedMusicPlayer(onlineMusic);
	        player = new VolumeControlDecorator(player, 50);
	        player = new EqualizerDecorator(player, "Classical");
	        player.playMusic();

	        
	        MusicSource radioMusic = new RadioStationMusic("Radio 101");
	        player = new AdvancedMusicPlayer(radioMusic);
	        player = new VolumeControlDecorator(player, 85);
	        player = new EqualizerDecorator(player, "Pop");
	        player.playMusic();
	    }
}
