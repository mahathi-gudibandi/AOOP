package com.example.musicstreaming;

public class AdvancedMusicPlayer implements MusicPlayer {
	private MusicSource musicSource;

    public AdvancedMusicPlayer(MusicSource musicSource) {
        this.musicSource = musicSource;
    }

    @Override
    public void playMusic() {
        musicSource.play();
    }
}
