package com.example.musicstreaming;

public interface MusicPlayer {
	void playMusic();
}
