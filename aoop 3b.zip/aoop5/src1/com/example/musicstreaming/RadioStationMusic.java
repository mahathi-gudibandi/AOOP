package com.example.musicstreaming;

public class RadioStationMusic implements MusicSource {
	private String station;

    public RadioStationMusic(String station) {
        this.station = station;
    }
    @Override
    public void play() {
        System.out.println("Playing music from radio station: " + station);
    }
}
