package com.example.musicstreaming;

public class LocalFileMusic implements MusicSource {
	 private String filePath;

	    public LocalFileMusic(String filePath) {
	        this.filePath = filePath;
	    }

	    @Override
	    public void play() {
	        System.out.println("Playing music from local file: " + filePath);
	    }
}
