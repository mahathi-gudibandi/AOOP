package com.example.musicstreaming;

public class VolumeControlDecorator implements MusicPlayer{
	  private MusicPlayer decoratedMusicPlayer;
	    private int volumeLevel;

	    public VolumeControlDecorator(MusicPlayer decoratedMusicPlayer, int volumeLevel) {
	        this.decoratedMusicPlayer = decoratedMusicPlayer;
	        this.volumeLevel = volumeLevel;
	    }

	    @Override
	    public void playMusic() {
	        decoratedMusicPlayer.playMusic();
	        System.out.println("Volume level set to: " + volumeLevel);
	    }
}
