package om.example.library;
import java.util.ArrayList;
import java.util.List;
public class BookRepository implements IBookRepository {
	 private List<Book> books = new ArrayList<>();
	    @Override
	    public void addBook(Book book) {
	        books.add(book);
	        System.out.println("Added book: " + book.getTitle());
	    }
	    @Override
	    public void removeBook(Book book) {
	        books.remove(book);
	        System.out.println("Removed book: " + book.getTitle());
	    }
	    @Override
	    public Book findBookByIsbn(String isbn) {
	        for (Book book : books) {
	            if (book.getIsbn().equals(isbn)) {
	                return book;
	            }
	        }
	        return null;
	    }
	    @Override
	    public List<Book> getAllBooks() {
	        return new ArrayList<>(books);
	    }
	}

