package om.example.library;

public class Book implements Borrowable {
	private String title;
    private String author;
    private String isbn;
    private boolean isBorrowed;

    public Book(String title, String author, String isbn) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.isBorrowed = false;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getIsbn() {
        return isbn;
    }

    @Override
    public void borrow(String memberId) {
        if (!isBorrowed) {
            isBorrowed = true;
            System.out.println(title + " has been borrowed by member ID: " + memberId);
        } else {
            System.out.println(title + " is currently borrowed.");
        }
    }

    @Override
    public void returnBook() {
        if (isBorrowed) {
            isBorrowed = false;
            System.out.println(title + " has been returned.");
        }
    }
}
