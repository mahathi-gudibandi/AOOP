package om.example.library;

public class Main {
	 public static void main(String[] args) {	        
	        IBookRepository bookRepository = new BookRepository();	        	        
	        Library library = new Library(bookRepository);	        	       
	        Book book1 = new Book("The Catcher in the Rye", "J.D. Salinger", "123456789");
	        Book book2 = new Book("To Kill a Mockingbird", "Harper Lee", "987654321");
	        library.addNewBook(book1);
	        library.addNewBook(book2);	        	        
	        LibraryMember member = new StudentMember("001", "John Doe", "STU1001");	        	        
	        library.borrowBook("123456789", member.getMemberId());	      	        
	        library.returnBook("123456789");
	        library.removeBook("987654321");
	    }
}
