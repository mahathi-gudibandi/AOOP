package om.example.library;

public interface Borrowable {
	void borrow(String memberId);
    void returnBook();
}
