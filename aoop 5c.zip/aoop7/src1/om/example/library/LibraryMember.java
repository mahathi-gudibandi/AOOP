package om.example.library;

public class LibraryMember implements Member {
	private String memberId;
    private String name;
    public LibraryMember(String memberId, String name) {
        this.memberId = memberId;
        this.name = name;
    }
    @Override
    public String getMemberId() {
        return memberId;
    }
    @Override
    public String getName() {
        return name;
    }
}
