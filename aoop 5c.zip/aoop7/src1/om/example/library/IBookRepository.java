package om.example.library;
import java.util.List;
public interface IBookRepository {
	 void addBook(Book book);
	    void removeBook(Book book);
	    Book findBookByIsbn(String isbn);
	    List<Book> getAllBooks();
}
