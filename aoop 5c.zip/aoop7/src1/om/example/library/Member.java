package om.example.library;

public interface Member {
	String getMemberId();
    String getName();
}
