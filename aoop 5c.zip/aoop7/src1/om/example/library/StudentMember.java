package om.example.library;

public class StudentMember extends LibraryMember{
	private String studentId;
    public StudentMember(String memberId, String name, String studentId) {
        super(memberId, name);
        this.studentId = studentId;
    }
    public String getStudentId() {
        return studentId;
    }
}
