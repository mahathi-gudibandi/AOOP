package om.example.library;

public class Library {
	private IBookRepository bookRepository;
    public Library(IBookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }
    public void addNewBook(Book book) {
        bookRepository.addBook(book);
    }
    public void removeBook(String isbn) {
        Book book = bookRepository.findBookByIsbn(isbn);
        if (book != null) {
            bookRepository.removeBook(book);
        } else {
            System.out.println("Book not found.");
        }
    }
    public void borrowBook(String isbn, String memberId) {
        Book book = bookRepository.findBookByIsbn(isbn);
        if (book != null) {
            book.borrow(memberId);
        } else {
            System.out.println("Book not found.");
        }
    }
    public void returnBook(String isbn) {
        Book book = bookRepository.findBookByIsbn(isbn);
        if (book != null) {
            book.returnBook();
        } else {
            System.out.println("Book not found.");
        }
    }
}
