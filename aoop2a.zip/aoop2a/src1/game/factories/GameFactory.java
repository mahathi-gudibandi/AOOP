package game.factories;

import game.powerups.PowerUp;
import game.weapons.Weapon;

public interface GameFactory {
	Weapon createWeapon();
    PowerUp createPowerUp();
}
