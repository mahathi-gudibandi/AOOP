package game.factories;

import game.powerups.*;
import game.weapons.*;

public class EasyGameFactory implements GameFactory {
	  @Override
	    public Weapon createWeapon() {
	        return new EasyWeapon();
	    }

	    @Override
	    public PowerUp createPowerUp() {
	        return new EasyPowerUp();
	    }
}
