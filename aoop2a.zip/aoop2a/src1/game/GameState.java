package game;

public class GameState {
	private static GameState instance;
    private int level;
    private String difficulty;

    private GameState() {
        this.level = 1;  
        this.difficulty = "Easy";  
    }

    public static synchronized GameState getInstance() {
        if (instance == null) {
            instance = new GameState();
        }
        return instance;
    }

    public void nextLevel() {
        level++;
        System.out.println("Level up! Current level: " + level);
    }

    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public int getLevel() {
        return level;
    }
}
