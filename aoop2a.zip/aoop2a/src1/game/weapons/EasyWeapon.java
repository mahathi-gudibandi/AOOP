package game.weapons;

public class EasyWeapon implements Weapon{
	@Override
    public void use() {
        System.out.println("Using easy weapon!");
    }
}
