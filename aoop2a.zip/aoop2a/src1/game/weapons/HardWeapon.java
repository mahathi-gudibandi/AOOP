package game.weapons;

public class HardWeapon implements Weapon{
	@Override
    public void use() {
        System.out.println("Using hard weapon!");
    }
}
