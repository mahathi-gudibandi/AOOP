package game.weapons;

public interface Weapon {
	void use();
}
