package game.powerups;

public interface PowerUp {
	void activate();
}
