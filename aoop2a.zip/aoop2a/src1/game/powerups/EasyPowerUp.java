package game.powerups;

public class EasyPowerUp implements PowerUp{
	 @Override
	    public void activate() {
	        System.out.println("Activating easy power-up!");
	    }
}
