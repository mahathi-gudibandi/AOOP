package game.powerups;

public class HardPowerUp implements PowerUp {
	 @Override
	    public void activate() {
	        System.out.println("Activating hard power-up!");
	    }
}
