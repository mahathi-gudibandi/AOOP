package game.enemies;

public class HardEnemy implements Enemy{
	@Override
    public void attack() {
        System.out.println("Hard Enemy attacks with maximum force!");
    }
}
