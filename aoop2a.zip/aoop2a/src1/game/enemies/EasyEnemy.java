package game.enemies;

public class EasyEnemy implements Enemy{
	@Override
    public void attack() {
        System.out.println("Easy Enemy attacks with basic force!");
    }
}
