package game.enemies;

public interface Enemy {
	void attack();
}
