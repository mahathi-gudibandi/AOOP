package com.boundedbuffer.app;

public class Main {
	public static void main(String[] args) {
       
        BoundedBuffer buffer = new BoundedBuffer(10);

       
        Thread producerThread = new Thread(new Producer(buffer));
        Thread consumerThread = new Thread(new Consumer(buffer));

        producerThread.start();
        consumerThread.start();

        
        try {
            Thread.sleep(10000);  
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

       
        producerThread.interrupt();
        consumerThread.interrupt();
    }
}
