package com.example.musicstreaming;

public class VolumeControlDecorator implements MusicSource {
	private MusicSource decoratedMusicSource;
    private int volumeLevel;

    public VolumeControlDecorator(MusicSource decoratedMusicSource, int volumeLevel) {
        this.decoratedMusicSource = decoratedMusicSource;
        this.volumeLevel = volumeLevel;
    }

    @Override
    public void play() {
        decoratedMusicSource.play();
        System.out.println("Volume level set to: " + volumeLevel);
    }
}
