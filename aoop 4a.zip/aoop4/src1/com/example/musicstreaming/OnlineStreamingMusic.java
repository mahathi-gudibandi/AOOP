package com.example.musicstreaming;

public class OnlineStreamingMusic implements MusicSource {
	private String url;

    public OnlineStreamingMusic(String url) {
        this.url = url;
    }

    @Override
    public void play() {
        System.out.println("Playing music from online streaming: " + url);
    }
}
