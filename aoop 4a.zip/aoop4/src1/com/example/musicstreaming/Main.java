package com.example.musicstreaming;

public class Main {
	public static void main(String[] args) {
        MusicSource localFileMusic = new LocalFileMusic("song.mp3");
        MusicSource decoratedLocalFileMusic = new VolumeControlDecorator(
            new EqualizerDecorator(localFileMusic, "Bass Boost"), 75);
        decoratedLocalFileMusic.play();
        MusicSource onlineMusic = new OnlineStreamingMusic("http://musicstreaming.com/song");
        MusicSource decoratedOnlineMusic = new VolumeControlDecorator(
            new EqualizerDecorator(onlineMusic, "Classical"), 50);
        decoratedOnlineMusic.play();
        MusicSource radioMusic = new RadioStationMusic("Radio 101");
        MusicSource decoratedRadioMusic = new EqualizerDecorator(
            new VolumeControlDecorator(radioMusic, 85), "Pop");
        decoratedRadioMusic.play();
    }
}
