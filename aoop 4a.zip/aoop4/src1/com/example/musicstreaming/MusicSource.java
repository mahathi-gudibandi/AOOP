package com.example.musicstreaming;

public interface MusicSource {
	void play();
}
