package com.example.musicstreaming;

public class EqualizerDecorator implements MusicSource {
	 private MusicSource decoratedMusicSource;
	    private String equalizerSetting;

	    public EqualizerDecorator(MusicSource decoratedMusicSource, String equalizerSetting) {
	        this.decoratedMusicSource = decoratedMusicSource;
	        this.equalizerSetting = equalizerSetting;
	    }

	    @Override
	    public void play() {
	        decoratedMusicSource.play();
	        System.out.println("Equalizer setting applied: " + equalizerSetting);
	    }
}
