package com.contacts;

public class ContactManger {

}
