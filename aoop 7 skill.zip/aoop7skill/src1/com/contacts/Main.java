package com.contacts;

public class Main {
	public static void main(String[] args) {
        ContactManager contactManager = new ContactManager();

        Contact contact1 = new Contact("Alice", "123-456-7890", "alice@example.com");
        Contact contact2 = new Contact("Bob", "234-567-8901", "bob@example.com");
        Contact contact3 = new Contact("Charlie", "345-678-9012", "charlie@example.com");

        contactManager.addContact(contact1);
        contactManager.addContact(contact2);
        contactManager.addContact(contact3);

        System.out.println("All Contacts:");
        contactManager.displayAllContacts();

        System.out.println("\nSearching for contact by name 'Bob':");
        System.out.println(contactManager.findContactByName("Bob"));

        System.out.println("\nSearching for contact by phone number '345-678-9012':");
        System.out.println(contactManager.findContactByPhoneNumber("345-678-9012"));

        System.out.println("\nRemoving contact by name 'Alice':");
        contactManager.removeContactByName("Alice");

        System.out.println("\nAll Contacts after removal:");
        contactManager.displayAllContacts();
    }
}
