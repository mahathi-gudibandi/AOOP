package com.contacts;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
public class ContactManager {
	private Set<Contact> contacts = new HashSet<>();
    private Map<String, Contact> contactsByName = new HashMap<>();
    private Map<String, Contact> contactsByPhoneNumber = new HashMap<>();

    public boolean addContact(Contact contact) {
        if (contacts.add(contact)) {
            contactsByName.put(contact.getName(), contact);
            contactsByPhoneNumber.put(contact.getPhoneNumber(), contact);
            return true;
        }
        return false;
    }

    public boolean removeContactByName(String name) {
        Contact contact = contactsByName.remove(name);
        if (contact != null) {
            contacts.remove(contact);
            contactsByPhoneNumber.remove(contact.getPhoneNumber());
            return true;
        }
        return false;
    }

    public Contact findContactByName(String name) {
        return contactsByName.get(name);
    }

    public Contact findContactByPhoneNumber(String phoneNumber) {
        return contactsByPhoneNumber.get(phoneNumber);
    }

    public void displayAllContacts() {
        contacts.forEach(System.out::println);
    }
}
