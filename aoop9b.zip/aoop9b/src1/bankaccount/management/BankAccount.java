package bankaccount.management;

public class BankAccount {
	 private double balance;

	    public BankAccount(double initialBalance) {
	        this.balance = initialBalance;
	    }

	    // Synchronized deposit method to ensure thread safety
	    public synchronized void deposit(double amount) {
	        if (amount > 0) {
	            balance += amount;
	            System.out.println(Thread.currentThread().getName() + " deposited: " + amount + ", New Balance: " + balance);
	        } else {
	            System.out.println(Thread.currentThread().getName() + " tried to deposit a negative amount.");
	        }
	    }

	    // Synchronized withdraw method to ensure thread safety
	    public synchronized void withdraw(double amount) {
	        if (amount > 0 && amount <= balance) {
	            balance -= amount;
	            System.out.println(Thread.currentThread().getName() + " withdrew: " + amount + ", New Balance: " + balance);
	        } else if (amount > balance) {
	            System.out.println(Thread.currentThread().getName() + " tried to withdraw: " + amount + " but insufficient funds.");
	        } else {
	            System.out.println(Thread.currentThread().getName() + " tried to withdraw a negative amount.");
	        }
	    }

	    // Method to get the current balance
	    public synchronized double getBalance() {
	        return balance;
	    }
}
