package bankaccount.management;

public class Main {
	 public static void main(String[] args) {
	        
	        BankAccount sharedAccount = new BankAccount(1000.0);

	        TransactionTask depositTask1 = new TransactionTask(sharedAccount, true, 200);
	        TransactionTask withdrawTask1 = new TransactionTask(sharedAccount, false, 150);
	        TransactionTask depositTask2 = new TransactionTask(sharedAccount, true, 300);
	        TransactionTask withdrawTask2 = new TransactionTask(sharedAccount, false, 500);

	     
	        Thread user1 = new Thread(depositTask1, "User1");
	        Thread user2 = new Thread(withdrawTask1, "User2");
	        Thread user3 = new Thread(depositTask2, "User3");
	        Thread user4 = new Thread(withdrawTask2, "User4");

	        user1.start();
	        user2.start();
	        user3.start();
	        user4.start();

	        
	        try {
	            user1.join();
	            user2.join();
	            user3.join();
	            user4.join();
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }

	     
	        System.out.println("Final balance: " + sharedAccount.getBalance());
	    }
}
