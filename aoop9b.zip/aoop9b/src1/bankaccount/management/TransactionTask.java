package bankaccount.management;

public class TransactionTask implements Runnable{
	private final BankAccount bankAccount;
    private final boolean depositTask;
    private final double amount;

    public TransactionTask(BankAccount bankAccount, boolean depositTask, double amount) {
        this.bankAccount = bankAccount;
        this.depositTask = depositTask;
        this.amount = amount;
    }

    @Override
    public void run() {
        if (depositTask) {
            bankAccount.deposit(amount);
        } else {
            bankAccount.withdraw(amount);
        }
    }
}
