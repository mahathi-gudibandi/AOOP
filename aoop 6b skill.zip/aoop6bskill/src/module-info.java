/**
 * 
 */
/**
 * 
 */
module aoop6bskill {
}