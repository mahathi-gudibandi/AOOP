package com.messaging.app;

public class Producer implements Runnable {
	private SharedBuffer sharedBuffer;

    public Producer(SharedBuffer sharedBuffer) {
        this.sharedBuffer = sharedBuffer;
    }

    @Override
    public void run() {
        try {
            int messageNumber = 1;
            while (true) {
                String message = "Message " + messageNumber++;
                sharedBuffer.produce(message);
                Thread.sleep(1000); 
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.println("Producer interrupted");
        }
    }
}
