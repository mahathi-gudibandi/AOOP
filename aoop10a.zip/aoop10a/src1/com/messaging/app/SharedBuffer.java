package com.messaging.app;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class SharedBuffer {
	private BlockingQueue<String> queue;

    public SharedBuffer(int capacity) {
        this.queue = new LinkedBlockingQueue<>(capacity);
    }

   
    public void produce(String message) throws InterruptedException {
        queue.put(message);
        System.out.println("Produced: " + message);
    }

   
    public String consume() throws InterruptedException {
        String message = queue.take();
        System.out.println("Consumed: " + message);
        return message;
    }
}
