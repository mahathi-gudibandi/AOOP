package com.messaging.app;

public class Consumer implements Runnable {
	 private SharedBuffer sharedBuffer;

	    public Consumer(SharedBuffer sharedBuffer) {
	        this.sharedBuffer = sharedBuffer;
	    }

	    @Override
	    public void run() {
	        try {
	            while (true) {
	                sharedBuffer.consume();
	                Thread.sleep(1500); 
	            }
	        } catch (InterruptedException e) {
	            Thread.currentThread().interrupt();
	            System.out.println("Consumer interrupted");
	        }
	    }
}
