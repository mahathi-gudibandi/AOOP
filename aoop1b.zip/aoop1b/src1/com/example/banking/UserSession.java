package com.example.banking;
public class UserSession {
	 private static UserSession instance;
	    private boolean loggedIn;
	    private UserSession() {
	        loggedIn = false;
	    }
	    public static UserSession getInstance() {
	        if (instance == null) {
	            synchronized (UserSession.class) {
	                if (instance == null) {
	                    instance = new UserSession();
	                }
	            }
	        }
	        return instance;
	    }
	    public void login() {
	        loggedIn = true;
	        System.out.println("User logged in.");
	    }
	    public void logout() {
	        loggedIn = false;
	        System.out.println("User logged out.");
	    }
	    public boolean isLoggedIn() {
	        return loggedIn;
	    }
}
