package com.example.banking;
import java.util.Scanner;
public class Main {
	  public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        BankAccount account = new BankAccount(1000.0); 
	        UserSession session = UserSession.getInstance();

	        boolean exit = false;
	        while (!exit) {
	            System.out.println("\nBanking Operations");
	            System.out.println("1. Login");
	            System.out.println("2. Logout");
	            System.out.println("3. View Balance");
	            System.out.println("4. Deposit");
	            System.out.println("5. Withdraw");
	            System.out.println("6. Exit");
	            System.out.print("Choose an option: ");
	            int choice = scanner.nextInt();

	            switch (choice) {
	                case 1:
	                    session.login();
	                    break;
	                case 2:
	                    session.logout();
	                    break;
	                case 3:
	                    account.viewBalance();
	                    break;
	                case 4:
	                    System.out.print("Enter amount to deposit: ");
	                    double depositAmount = scanner.nextDouble();
	                    account.deposit(depositAmount);
	                    break;
	                case 5:
	                    System.out.print("Enter amount to withdraw: ");
	                    double withdrawAmount = scanner.nextDouble();
	                    account.withdraw(withdrawAmount);
	                    break;
	                case 6:
	                    exit = true;
	                    System.out.println("Exiting...");
	                    break;
	                default:
	                    System.out.println("Invalid choice. Please try again.");
	            }
	        }

	        scanner.close();
	    }
}
