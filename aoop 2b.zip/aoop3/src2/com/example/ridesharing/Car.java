package com.example.ridesharing;

public class Car implements Vehicle {
	   @Override
	    public void bookRide() {
	        System.out.println("Car ride has been booked.");
	    }
	}

	
