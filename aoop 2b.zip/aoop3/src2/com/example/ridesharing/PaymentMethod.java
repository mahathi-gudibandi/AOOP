package com.example.ridesharing;

public interface PaymentMethod {
	 void processPayment(double amount);
}
