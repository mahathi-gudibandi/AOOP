package com.example.ridesharing;

public interface VehicleFactory {
	 Vehicle createVehicle();
}
