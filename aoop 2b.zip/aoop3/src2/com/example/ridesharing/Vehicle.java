package com.example.ridesharing;

public interface Vehicle {
	void bookRide();
}
