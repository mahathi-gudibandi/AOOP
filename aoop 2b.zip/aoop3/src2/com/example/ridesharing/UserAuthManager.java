package com.example.ridesharing;

public class UserAuthManager {
	 private static UserAuthManager instance;
	    private UserAuthManager() {
	    }

	    public static UserAuthManager getInstance() {
	        if (instance == null) {
	            instance = new UserAuthManager();
	        }
	        return instance;
	    }

	    public boolean authenticate(String username, String password) {
	       
	        return "user".equals(username) && "password".equals(password);
	    }
}
