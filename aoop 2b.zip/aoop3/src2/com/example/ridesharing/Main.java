package com.example.ridesharing;

public class Main {
	 public static void main(String[] args) {
	        // Authenticate User
	        UserAuthManager authManager = UserAuthManager.getInstance();
	        if (authManager.authenticate("user", "password")) {
	            System.out.println("User authenticated successfully!");

	            // Vehicle booking
	            VehicleFactory carFactory = new CarFactory();
	            Vehicle car = carFactory.createVehicle();
	            car.bookRide();

	            VehicleFactory bikeFactory = new BikeFactory();
	            Vehicle bike = bikeFactory.createVehicle();
	            bike.bookRide();

	            // Payment processing
	            PaymentFactory creditCardFactory = new CreditCardFactory();
	            PaymentMethod creditCardPayment = creditCardFactory.createPaymentMethod();
	            creditCardPayment.processPayment(20.0);

	            PaymentFactory payPalFactory = new PayPalFactory();
	            PaymentMethod payPalPayment = payPalFactory.createPaymentMethod();
	            payPalPayment.processPayment(15.0);
	        } else {
	            System.out.println("Authentication failed!");
	        }
	    }
}
