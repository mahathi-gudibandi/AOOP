package com.example.ridesharing;

public class Scooter implements Vehicle{
	@Override
    public void bookRide() {
        System.out.println("Scooter ride has been booked.");
    }
}
