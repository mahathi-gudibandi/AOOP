package com.example.ridesharing;

public class CashFactory implements PaymentFactory {
	@Override
    public PaymentMethod createPaymentMethod() {
        return new CashPayment();
    }
}
